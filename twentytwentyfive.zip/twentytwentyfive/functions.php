<?php
/**
 * Twenty Twenty-Five functions and definitions.
 *
 * @link https://developer.wordpress.org/themes/basics/theme-functions/
 *
 * @package WordPress
 * @subpackage Twenty_Twenty_Five
 * @since Twenty Twenty-Five 1.0
 */

// Adds theme support for post formats.
if ( ! function_exists( 'twentytwentyfive_post_format_setup' ) ) :
	/**
	 * Adds theme support for post formats.
	 *
	 * @since Twenty Twenty-Five 1.0
	 *
	 * @return void
	 */
	function twentytwentyfive_post_format_setup() {
		add_theme_support( 'post-formats', array( 'aside', 'audio', 'chat', 'gallery', 'image', 'link', 'quote', 'status', 'video' ) );
	}
endif;
add_action( 'after_setup_theme', 'twentytwentyfive_post_format_setup' );

// Enqueues editor-style.css in the editors.
if ( ! function_exists( 'twentytwentyfive_editor_style' ) ) :
	/**
	 * Enqueues editor-style.css in the editors.
	 *
	 * @since Twenty Twenty-Five 1.0
	 *
	 * @return void
	 */
	function twentytwentyfive_editor_style() {
		add_editor_style( 'assets/css/editor-style.css' );
	}
endif;
add_action( 'after_setup_theme', 'twentytwentyfive_editor_style' );

// Enqueues style.css on the front.
if ( ! function_exists( 'twentytwentyfive_enqueue_styles' ) ) :
	/**
	 * Enqueues style.css on the front.
	 *
	 * @since Twenty Twenty-Five 1.0
	 *
	 * @return void
	 */
	function twentytwentyfive_enqueue_styles() {
		wp_enqueue_style(
			'twentytwentyfive-style',
			get_parent_theme_file_uri( 'style.css' ),
			array(),
			wp_get_theme()->get( 'Version' )
		);
	}
endif;
add_action( 'wp_enqueue_scripts', 'twentytwentyfive_enqueue_styles' );

// Registers custom block styles.
if ( ! function_exists( 'twentytwentyfive_block_styles' ) ) :
	/**
	 * Registers custom block styles.
	 *
	 * @since Twenty Twenty-Five 1.0
	 *
	 * @return void
	 */
	function twentytwentyfive_block_styles() {
		register_block_style(
			'core/list',
			array(
				'name'         => 'checkmark-list',
				'label'        => __( 'Checkmark', 'twentytwentyfive' ),
				'inline_style' => '
				ul.is-style-checkmark-list {
					list-style-type: "\2713";
				}

				ul.is-style-checkmark-list li {
					padding-inline-start: 1ch;
				}',
			)
		);
	}
endif;
add_action( 'init', 'twentytwentyfive_block_styles' );

// Registers pattern categories.
if ( ! function_exists( 'twentytwentyfive_pattern_categories' ) ) :
	/**
	 * Registers pattern categories.
	 *
	 * @since Twenty Twenty-Five 1.0
	 *
	 * @return void
	 */
	function twentytwentyfive_pattern_categories() {

		register_block_pattern_category(
			'twentytwentyfive_page',
			array(
				'label'       => __( 'Pages', 'twentytwentyfive' ),
				'description' => __( 'A collection of full page layouts.', 'twentytwentyfive' ),
			)
		);

		register_block_pattern_category(
			'twentytwentyfive_post-format',
			array(
				'label'       => __( 'Post formats', 'twentytwentyfive' ),
				'description' => __( 'A collection of post format patterns.', 'twentytwentyfive' ),
			)
		);
	}
endif;




// Remove any previous conflicting hooks (optional, safe to leave)
remove_action('pre_get_posts', 'custom_woocommerce_search');
remove_action('pre_get_posts', 'hybrid_woocommerce_fuzzy_search');

// Add the hybrid fuzzy search
add_action('pre_get_posts', 'final_hybrid_woocommerce_fuzzy_search');

function final_hybrid_woocommerce_fuzzy_search($query) {
    // Only modify main WooCommerce search queries
    if (!is_admin() && $query->is_main_query() && $query->is_search() && (is_shop() || is_product_category() || is_product_tag())) {
        global $wpdb;
        $search_term = $query->get('s');

        if (!empty($search_term)) {
            // Reset default search
            $query->set('s', '');

            // Fetch all products with title and SKU
            $products = $wpdb->get_results("
                SELECT p.ID, p.post_title, pm.meta_value AS sku
                FROM {$wpdb->posts} p
                LEFT JOIN {$wpdb->postmeta} pm ON (p.ID = pm.post_id AND pm.meta_key = '_sku')
                WHERE p.post_type = 'product' AND p.post_status = 'publish'
            ");

            $matched_ids = [];
            $search = strtolower($search_term);
            $search_metaphone = metaphone($search);

            foreach ($products as $product) {
                $title = strtolower($product->post_title);
                $sku   = strtolower($product->sku ?? '');

                $found = false;

                // --- 1. Exact / Partial Match (LIKE) ---
                if (strpos($title, $search) !== false || strpos($sku, $search) !== false) {
                    $found = true;
                }

                // --- 2. Phonetic Match (Metaphone) ---
                if (!$found && (metaphone($title) === $search_metaphone || ($sku && metaphone($sku) === $search_metaphone))) {
                    $found = true;
                }

                // --- 3. Typo / Misspelling Match (Levenshtein) ---
                if (!$found && (levenshtein($search, $title) <= 3 || ($sku && levenshtein($search, $sku) <= 2))) {
                    $found = true;
                }

                // --- 4. Word-level Phonetic + Levenshtein for compound words ---
                if (!$found) {
                    // Title words
                    $title_words = preg_split('/[\s\p{P}]+/u', $title);
                    foreach ($title_words as $word) {
                        if (empty($word)) continue;
                        if (metaphone($word) === $search_metaphone || levenshtein($search, $word) <= 3) {
                            $found = true;
                            break;
                        }
                    }

                    // SKU words
                    if (!$found && $sku) {
                        $sku_words = preg_split('/[\s\p{P}]+/u', $sku);
                        foreach ($sku_words as $word) {
                            if (empty($word)) continue;
                            if (metaphone($word) === $search_metaphone || levenshtein($search, $word) <= 2) {
                                $found = true;
                                break;
                            }
                        }
                    }
                }

                if ($found) {
                    $matched_ids[] = $product->ID;
                }
            }

            // Ensure unique IDs
            $matched_ids = array_unique($matched_ids);

            // Set the matched product IDs for the query
            if (!empty($matched_ids)) {
                $query->set('post__in', $matched_ids);
            } else {
                $query->set('post__in', [0]); // No matches found
            }
        }
    }
}

//add this code
// Add meta boxes to Product edit screen
function custom_product_meta_boxes() {
    add_meta_box(
        'custom_description_box',
        'Custom Product Description',
        'render_custom_description_box',
        'product',
        'normal',
        'high'
    );

    add_meta_box(
        'custom_variables_box',
        'Custom Variable Details',
        'render_custom_variables_box',
        'product',
        'normal',
        'default'
    );
}
add_action('add_meta_boxes', 'custom_product_meta_boxes');

// Render Custom Description field
function render_custom_description_box($post) {
    $custom_description = get_post_meta($post->ID, '_custom_description', true);
    echo '<textarea name="custom_description" style="width:100%; height:120px;">' . esc_textarea($custom_description) . '</textarea>';
}

// Render Custom Variable fields (simple example)
function render_custom_variables_box($post) {
    $variables = get_post_meta($post->ID, '_custom_variables', true);
    if (!is_array($variables)) $variables = array(['name' => '', 'value' => '']);
    echo '<div id="custom-vars-container">';
    foreach ($variables as $i => $var) {
        echo '<p>
            <input type="text" name="custom_variables['.$i.'][name]" placeholder="Variable Name" value="'.esc_attr($var['name']).'" style="width:45%; margin-right:2%;">
            <input type="text" name="custom_variables['.$i.'][value]" placeholder="Value" value="'.esc_attr($var['value']).'" style="width:45%;">
        </p>';
    }
    echo '</div>';
    echo '<button type="button" id="add-var-row" class="button">+ Add Variable</button>';
    ?>
    <script>
    document.addEventListener('DOMContentLoaded', function(){
        const btn = document.getElementById('add-var-row');
        const container = document.getElementById('custom-vars-container');
        btn.addEventListener('click', function(){
            const count = container.querySelectorAll('p').length;
            const html = `<p>
                <input type="text" name="custom_variables[${count}][name]" placeholder="Variable Name" style="width:45%; margin-right:2%;">
                <input type="text" name="custom_variables[${count}][value]" placeholder="Value" style="width:45%;">
            </p>`;
            container.insertAdjacentHTML('beforeend', html);
        });
    });
    </script>
    <?php
}

// Save Meta Box Data
function save_custom_product_meta($post_id) {
    if (array_key_exists('custom_description', $_POST)) {
        update_post_meta($post_id, '_custom_description', sanitize_textarea_field($_POST['custom_description']));
    }
    if (array_key_exists('custom_variables', $_POST)) {
        $variables = array_map(function($v){
            return [
                'name' => sanitize_text_field($v['name']),
                'value' => sanitize_text_field($v['value'])
            ];
        }, $_POST['custom_variables']);
        update_post_meta($post_id, '_custom_variables', $variables);
    }
}
add_action('save_post', 'save_custom_product_meta');

//add bloew for code
