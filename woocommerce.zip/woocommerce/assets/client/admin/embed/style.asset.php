<?php return array('version' => '928ec344c33c5a772086');
