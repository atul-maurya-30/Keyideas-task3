<?php
/**
 * Legacy Functions
 *
 * @package YITH\Wishlist\Classes\Legacy
 * @author  YITH <plugins@yithemes.com>
 * @version 3.0.0
 */

defined( 'YITH_WCWL' ) || exit; // Exit if accessed directly
