<?php
/**
 * WooCommerce Compatibility File
 * Custom layout integration for your theme
 */

// Exit if accessed directly
if ( ! defined( 'ABSPATH' ) ) {
	exit;
}

/**
 * Declare WooCommerce support
 */
function custom_theme_add_woocommerce_support() {
	add_theme_support( 'woocommerce', array(
		'thumbnail_image_width' => 400,
		'single_image_width'    => 800,
		'product_grid'          => array(
			'default_rows'    => 3,
			'min_rows'        => 1,
			'default_columns' => 4,
			'min_columns'     => 1,
			'max_columns'     => 6,
		),
	) );
}
add_action( 'after_setup_theme', 'custom_theme_add_woocommerce_support' );

/**
 * Custom wrappers for WooCommerce pages
 */
remove_action( 'woocommerce_before_main_content', 'woocommerce_output_content_wrapper', 10 );
remove_action( 'woocommerce_after_main_content', 'woocommerce_output_content_wrapper_end', 10 );

function custom_theme_wrapper_start() {
	echo '<main id="main" class="site-main custom-woo-layout">';
}
function custom_theme_wrapper_end() {
	echo '</main>';
}
add_action( 'woocommerce_before_main_content', 'custom_theme_wrapper_start', 10 );
add_action( 'woocommerce_after_main_content', 'custom_theme_wrapper_end', 10 );

/**
 * Optional - Remove default sidebar if needed
 */
function custom_theme_disable_sidebar_on_shop() {
	if ( is_shop() || is_product() || is_product_category() ) {
		remove_action( 'woocommerce_sidebar', 'woocommerce_get_sidebar', 10 );
	}
}
add_action( 'template_redirect', 'custom_theme_disable_sidebar_on_shop' );

/**
 * Enqueue your WooCommerce custom CSS
 */
function custom_theme_woocommerce_style() {
	wp_enqueue_style( 'custom-woo-style', get_stylesheet_directory_uri() . '/custom-woo.css', array(), '1.0.0' );
}
add_action( 'wp_enqueue_scripts', 'custom_theme_woocommerce_style' );
